//  Copyright (c) 2017 Hartmut Kaiser
//
//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef HPX_UTIL_DETAIL_PP_EXPAND_HPP_INCLUDED
#define HPX_UTIL_DETAIL_PP_EXPAND_HPP_INCLUDED

// hpxinspect:noinclude:HPX_PP_EXPAND

#define HPX_PP_EXPAND(x) x

#endif


