//  Copyright (c) 2016 Hartmut Kaiser
//
//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#if !defined(HPX_PROCESS_MAR_12_2016_0911AM)
#define HPX_PROCESS_MAR_12_2016_0911AM

#include <hpx/components/process/process.hpp>
#include <hpx/components/process/util/initializers.hpp>

#endif

