////////////////////////////////////////////////////////////////////////////////
//  Copyright (C) 2010 Edward Diener
//  Copyright (c) 2015 Agustin Berge
//
//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
////////////////////////////////////////////////////////////////////////////////

#define TEST_VARIADIC_MACRO_SIMPLE(avalue,...) __VA_ARGS__

int main() {}
